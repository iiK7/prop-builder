fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'Prop k7_icbm_silo (built by tools/prop_builder)'

data_file 'DLC_ITYP_REQUEST' 'stream/k7_icbm_silo.ytyp'

client_script 'client.lua'
