fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'Prop k7_missile_launcher (built by tools/prop_builder)'

data_file 'DLC_ITYP_REQUEST' 'stream/k7_missile_launcher.ytyp'

client_script 'client.lua'
