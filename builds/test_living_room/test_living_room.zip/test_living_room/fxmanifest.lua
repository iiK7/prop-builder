fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'Room test_living_room (built from a photo by tools/prop_builder)'

data_file 'DLC_ITYP_REQUEST' 'stream/test_living_room_shell.ytyp'
data_file 'DLC_ITYP_REQUEST' 'stream/test_living_room_obj1.ytyp'

client_script 'client.lua'
