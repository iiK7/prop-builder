fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'Prop k7_shrapnel_a (built by tools/prop_builder)'

data_file 'DLC_ITYP_REQUEST' 'stream/k7_shrapnel_a.ytyp'

client_script 'client.lua'
