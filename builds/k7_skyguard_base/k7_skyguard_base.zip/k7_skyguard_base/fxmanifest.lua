fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'Prop k7_skyguard_base (built by tools/prop_builder)'

data_file 'DLC_ITYP_REQUEST' 'stream/k7_skyguard_base.ytyp'

client_script 'client.lua'
