fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'Prop k7_storm_shadow (built by tools/prop_builder)'

data_file 'DLC_ITYP_REQUEST' 'stream/k7_storm_shadow.ytyp'

client_script 'client.lua'
