fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'Prop token_check_chair (built by tools/prop_builder)'

data_file 'DLC_ITYP_REQUEST' 'stream/token_check_chair.ytyp'

client_script 'client.lua'
