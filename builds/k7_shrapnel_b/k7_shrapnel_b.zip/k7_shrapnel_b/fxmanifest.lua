fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'Prop k7_shrapnel_b (built by tools/prop_builder)'

data_file 'DLC_ITYP_REQUEST' 'stream/k7_shrapnel_b.ytyp'

client_script 'client.lua'
