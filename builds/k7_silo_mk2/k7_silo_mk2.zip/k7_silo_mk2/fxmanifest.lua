fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'Prop k7_silo_mk2 (built by tools/prop_builder)'

data_file 'DLC_ITYP_REQUEST' 'stream/k7_silo_mk2.ytyp'

client_script 'client.lua'
