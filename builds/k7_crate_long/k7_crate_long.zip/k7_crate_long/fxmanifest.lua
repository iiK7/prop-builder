fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'Prop k7_crate_long (built by tools/prop_builder)'

data_file 'DLC_ITYP_REQUEST' 'stream/k7_crate_long.ytyp'

client_script 'client.lua'
