fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'Prop prop_bedouin_tent (built by tools/prop_builder)'

data_file 'DLC_ITYP_REQUEST' 'stream/prop_bedouin_tent.ytyp'

client_script 'client.lua'
