fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'Prop k7_astros_rocket (built by tools/prop_builder)'

data_file 'DLC_ITYP_REQUEST' 'stream/k7_astros_rocket.ytyp'

client_script 'client.lua'
