fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'Prop prop_dallah (built by tools/prop_builder)'

data_file 'DLC_ITYP_REQUEST' 'stream/prop_dallah.ytyp'

client_script 'client.lua'
