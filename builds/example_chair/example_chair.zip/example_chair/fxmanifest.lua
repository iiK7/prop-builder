fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'Prop example_chair (built by tools/prop_builder)'

data_file 'DLC_ITYP_REQUEST' 'stream/example_chair.ytyp'

client_script 'client.lua'
