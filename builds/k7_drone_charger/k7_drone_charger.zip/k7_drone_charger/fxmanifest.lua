fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'Prop k7_drone_charger (built by tools/prop_builder)'

data_file 'DLC_ITYP_REQUEST' 'stream/k7_drone_charger.ytyp'

client_script 'client.lua'
