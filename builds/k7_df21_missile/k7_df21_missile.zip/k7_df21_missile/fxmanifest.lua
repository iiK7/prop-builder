fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'Prop k7_df21_missile (built by tools/prop_builder)'

data_file 'DLC_ITYP_REQUEST' 'stream/k7_df21_missile.ytyp'

client_script 'client.lua'
