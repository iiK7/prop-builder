fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'Prop test_chair_photo (built by tools/prop_builder)'

data_file 'DLC_ITYP_REQUEST' 'stream/test_chair_photo.ytyp'

client_script 'client.lua'
