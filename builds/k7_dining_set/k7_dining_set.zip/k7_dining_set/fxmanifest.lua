fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'Prop k7_dining_set (built by tools/prop_builder)'

data_file 'DLC_ITYP_REQUEST' 'stream/k7_dining_set.ytyp'

client_script 'client.lua'
