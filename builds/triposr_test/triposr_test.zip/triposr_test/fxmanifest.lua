fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'Prop triposr_test (built by tools/prop_builder)'

data_file 'DLC_ITYP_REQUEST' 'stream/triposr_test.ytyp'

client_script 'client.lua'
