fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'Prop k7_masnad (built by tools/prop_builder)'

data_file 'DLC_ITYP_REQUEST' 'stream/k7_masnad.ytyp'

client_script 'client.lua'
