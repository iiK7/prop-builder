fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'Room test_living_room_2 (built from a photo by tools/prop_builder)'

data_file 'DLC_ITYP_REQUEST' 'stream/test_living_room_2_shell.ytyp'
data_file 'DLC_ITYP_REQUEST' 'stream/test_living_room_2_obj1.ytyp'
data_file 'DLC_ITYP_REQUEST' 'stream/test_living_room_2_obj2.ytyp'
data_file 'DLC_ITYP_REQUEST' 'stream/test_living_room_2_obj3.ytyp'

client_script 'client.lua'
