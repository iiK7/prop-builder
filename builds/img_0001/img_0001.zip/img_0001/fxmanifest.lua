fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'Prop img_0001 (built by tools/prop_builder)'

data_file 'DLC_ITYP_REQUEST' 'stream/img_0001.ytyp'

client_script 'client.lua'
