fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'Prop abo_khsm (built by tools/prop_builder)'

data_file 'DLC_ITYP_REQUEST' 'stream/abo_khsm.ytyp'

client_script 'client.lua'
