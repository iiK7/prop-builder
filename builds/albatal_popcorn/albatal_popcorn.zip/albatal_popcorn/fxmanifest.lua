fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'Prop albatal_popcorn (built by tools/prop_builder)'

data_file 'DLC_ITYP_REQUEST' 'stream/albatal_popcorn.ytyp'

client_script 'client.lua'
