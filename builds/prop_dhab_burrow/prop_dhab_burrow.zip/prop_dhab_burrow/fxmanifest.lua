fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'Prop prop_dhab_burrow (built by tools/prop_builder)'

data_file 'DLC_ITYP_REQUEST' 'stream/prop_dhab_burrow.ytyp'

client_script 'client.lua'
